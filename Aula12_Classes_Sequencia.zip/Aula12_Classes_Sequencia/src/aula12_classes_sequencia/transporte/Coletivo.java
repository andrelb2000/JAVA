/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula12_classes_sequencia.transporte;

/**
 *
 * @author andre
 */
public class Coletivo {
    private String codigoColetivo;

    public Coletivo(String codigo) {
        this.codigoColetivo = codigo;
    }
    public void imprimeCodigo(){
        System.out.println("Codigo = "+codigoColetivo);
    }
    
    
    
    
}
